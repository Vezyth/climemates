<!doctype html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>ClimeMates</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="/css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="/images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
    <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,900&display=swap" rel="stylesheet">
    <!-- Google Fonts Roboto -->
    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />


    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <style>.active.link-secondary{
            font-weight: bold;
            color:#fff;
        }

    </style>
    <link href="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/css/compostnow.webflow.095f485e0.min.css" rel="stylesheet" type="text/css"/>
    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css"
        rel="stylesheet"
    />


    <!-- Intro settings -->
    <style>
        #intro {
            /* Margin to fix overlapping fixed navbar */
            margin-top: 58px;
        }

        @media (max-width: 991px) {
            #intro {
                /* Margin to fix overlapping fixed navbar */
                margin-top: 45px;
            }
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>


<div class="bg-dark">
    <nav class="navbar navbar-expand-md navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
        <div class="container-fluid ">
            <a class="navbar-brand" href="/">
                <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092620741805101096/logo.jpg" alt="..." height="36">
            </a>



            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNav">
                <ul class="nav navbar-nav navbar-right ">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">CharMates</a></li>
                            <li><a class="dropdown-item " href="/CompostMates">CompostMates</a></li>
                            <li><a class="dropdown-item" href="#">GardenMates</a></li>
                            <li><a class="dropdown-item " href="#">Next Step</a></li>
                        </ul>

                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">Our Impact</a></li>
                            <li><a class="dropdown-item " href="/OurStory">Our Story</a></li>
                            <li><a class="dropdown-item " href="/CrewMates">Meet the CrewMates</a></li>

                        </ul>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#">Blog</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">FAQ</a></li>
                            <li><a class="dropdown-item " href="/contact">Contact action</a></li>
                        </ul>

                    </li>


                </ul>
            </div>


        </div>
    </nav>

</div>
<div class="section wf-section">
    <div class="my-contain _2col meettheteam">
        <div class="text-wrapper hero">
            <h5 class="">Meet our CrewMates</h5>
            <h3 class="">We put the ‘eco’ in ‘ecosystem’!</h3>
            <h6 class="">We believe our work is vital to help combating the emissions problem, creating a healthier future for everyone.</h6>
        </div>
        <div class="_4pics-wrapper">
            <div class="_2pics-col">
                <div class="small-picture">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cbc00257ec4b81ca6b_pixel-square-23.png" loading="lazy" alt="">
                </div>
                <div class="large-picture">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648ccfd8bb6a2f7d599ca_pixel-square-31.png" loading="lazy" alt="" class="image">
                </div>
            </div>
            <div class="_2pics-col">
                <div class="large-picture">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cb3dba7f5eea793f16_pixel-square-21.png" loading="lazy" alt="">
                </div>
                <div class="small-picture">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9d3e2e840a1af5e9d_pixel-square-17.png" loading="lazy" alt="">
                </div>
            </div>
        </div>
    </div>
</div>


<div class="layout_padding  container">
    <section class="p-4 text-center mt-5 night-fade-gradient">
        <section class="text-center">

            <h3>Leading the CrewMates</h3>
            <hr class="my-4 container">
            <!--Grid row-->
            <div class="row d-flex justify-content-center">

                <div class="col-lg-3 col-md-4 mb-4">
                    <a>
                        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf2981d37b3f325f42_pixel-1-36.png" class="mb-4" alt="Picture" style="width:auto;">
                    </a>
                    <p>
                        Dionisius D. Sutanto
                    </p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-3 col-md-4 mb-4">
                    <a>
                        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf2981d37b3f325f42_pixel-1-36.png" class="mb-4" alt="Picture" style="width:auto;">
                    </a>
                    <p>
                        Faldy Effriant Pangemanan
                    </p>
                </div>
                <div class="col-lg-3 col-md-4 mb-4">
                    <a>
                        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf2981d37b3f325f42_pixel-1-36.png" class="mb-4" alt="Picture" style="width:auto;">
                    </a>
                    <p>
                        Irsyad Andayu
                    </p>
                </div>

                <div class="col-lg-3 col-md-4 mb-4">
                    <a>
                        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf2981d37b3f325f42_pixel-1-36.png" class="mb-4" alt="Picture" style="width:auto;">
                    </a>
                    <p>
                        Dewa Tira
                    </p>
                </div>

                <!--Grid column-->
            </div>
        </section>
    </section>
</div>



<section class="border p-4 text-center mt-5">
    <section class="text-center">


        <h3>We’re stronger together than we are apart. Collaboration makes the dream work.</h3>

        <hr class="my-4">

        <!--Grid row-->
        <div class="row">
            <!--Grid column-->
            <div class="col-lg-4 col-md-12 mb-4">
                <h5>The Soil Savers – composting team</h5>
                <p>
                    Our composting team oversees the magical process of composting. They are responsible for taking the incoming materials and monitoring the compost pile until it is fully cured.
                </p>
            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4">
                <h5>The Scarps Squad – logistic team</h5>



                <p>
                    Our drivers start their day at 7 am. The face of our ClimeMates, our drivers ensure our members receive ‘soil-sational’ services.
                </p>
            </div>
            <!--Grid column-->

            <!--Grid column-->
            <div class="col-lg-4 col-md-6 mb-4">
                <h5>The ClimeMates Counselors - support team</h5>
                <p>
                    our supports team and tech team, ready to tackle all the questions you may have and tackle any challenges of an evolving space.
                </p>
            </div>
            <!--Grid column-->
        </div>
        <!--Grid row-->
    </section>
</section>


<div class="section-6 wf-section">
    <div class="w-layout-grid grid-3">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf2981d37b3f325f42_pixel-1-36.png" loading="lazy" id="w-node-_20272221-9e22-4fa4-79ff-7c37f0860330-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f714a7e66d6d425279a_team-pixel2-39.png" loading="lazy" id="w-node-fe911aa9-41ae-e8b2-025f-f23e53c369f9-a07db751" height="" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f714a7e66d6d425279a_team-pixel2-39-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f714a7e66d6d425279a_team-pixel2-39.png 500w" sizes="(max-width: 500px) 100vw, 500px" alt="" class="image-36">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cbc00257ec4b81ca6b_pixel-square-23.png" loading="lazy" id="w-node-a4aaed5c-7409-f812-7921-8fc57b4efa94-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7170e42afd50bcefb4_team-pixel2-46.png" loading="lazy" id="w-node-_911c3a59-b94f-e64f-0f24-3cc8bd014363-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7170e42afd50bcefb4_team-pixel2-46-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7170e42afd50bcefb4_team-pixel2-46.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648ccfd8bb6a2f7d599ca_pixel-square-31.png" loading="lazy" id="w-node-_48ded9c9-33af-755a-51d0-2fabe37caa53-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7176543003a802fe15_team-pixel2-47.png" loading="lazy" id="w-node-_0c45c218-986e-6123-1ebc-07885ca29450-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7176543003a802fe15_team-pixel2-47-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7176543003a802fe15_team-pixel2-47.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9b8a3bb7b386b3385_pixel-square-13.png" loading="lazy" id="w-node-e212c27d-2ed7-3612-1177-53b575fcc4a4-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cb6dc29f1573ef4843_pixel-square-24.png" loading="lazy" id="w-node-_96016a21-fdf0-8b1b-56bc-0855bf68660e-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cbbfd19d55a2ab306d_pixel-square-28.png" loading="lazy" id="w-node-e6cf13ba-5daa-0f1f-c090-4ea9eecf187e-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9824569ee711e499d_pixel-square-10.png" loading="lazy" id="w-node-dd563121-6cbe-6d1c-0e8f-c62c2fd6363b-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f727654301c3b02fe1c_team-pixel2-48.png" loading="lazy" id="w-node-_361647c5-5e05-1c7f-4ddf-d3f502bc88ea-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f727654301c3b02fe1c_team-pixel2-48-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f727654301c3b02fe1c_team-pixel2-48.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9efdfefc0f421245b_pixel-square-15.png" loading="lazy" id="w-node-e633e90e-8f40-9623-183d-56d75ecfe8a5-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9b17711acacd3c396_pixel-square-08.png" loading="lazy" id="w-node-_77ddbfce-47e4-ccc6-aa42-6ee82c59498d-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c9d3e2e840a1af5e9d_pixel-square-17.png" loading="lazy" id="w-node-_32b5d53f-11c5-19b4-24d8-f610d4a85d7d-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7268635806efa45605_team-pixel2-50.png" loading="lazy" id="w-node-d836cbd1-0e45-c63e-b770-9f6983c1e741-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7268635806efa45605_team-pixel2-50-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f7268635806efa45605_team-pixel2-50.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c8b4b87a2c95a93013_pixel-square-02.png" loading="lazy" id="w-node-_57f0920b-1d83-2733-13be-e8f4bd2c0b44-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d33f54550db2d2adc_team-pixel3-40.png" loading="lazy" id="w-node-_22290388-388b-cfd5-cb40-7712ea50e3c7-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d33f54550db2d2adc_team-pixel3-40-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d33f54550db2d2adc_team-pixel3-40.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9ed6406522ace86fb4_team-pixel3-39.png" loading="lazy" id="w-node-ebcb25c8-9e9a-98f2-a72f-a264472f27bc-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9ed6406522ace86fb4_team-pixel3-39-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9ed6406522ace86fb4_team-pixel3-39.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648cb3dba7f5eea793f16_pixel-square-21.png" loading="lazy" id="w-node-fb04d818-c3dd-107f-7303-481dbedc1a3d-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f712efdac3244aa76a9_team-pixel2-45.png" loading="lazy" id="w-node-_53f597c4-3986-2677-200a-df1d89506d73-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f712efdac3244aa76a9_team-pixel2-45-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f712efdac3244aa76a9_team-pixel2-45.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72bcd106a027a75256_team-pixel2-51.png" loading="lazy" id="w-node-_62dc7e6a-a276-a42f-10c4-464d0ea34b62-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72bcd106a027a75256_team-pixel2-51-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72bcd106a027a75256_team-pixel2-51.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648ca58085d5f9fddb4f6_pixel-square-18.png" loading="lazy" id="w-node-fcf52488-1992-7577-bef6-7b9766c7a022-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eb0e2228f38b4b9ccc5_pixel-1-34.png" loading="lazy" id="w-node-_71f179f7-0ebe-848c-9748-902ead16db58-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c92981d37d81321f07_pixel-square-05.png" loading="lazy" id="w-node-_8ac5d8d9-19a1-cccd-fc96-9277c1d84d72-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d315365b7d746_team-pixel2-49.png" loading="lazy" id="w-node-f868a652-5339-3d2e-f1ee-41098b3e5ff4-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d315365b7d746_team-pixel2-49-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d315365b7d746_team-pixel2-49.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9e73c01afce9b3b33f_team-pixel3-41.png" loading="lazy" id="w-node-_6c5380d7-4c42-3d42-6758-16babc1858da-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9e73c01afce9b3b33f_team-pixel3-41-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9e73c01afce9b3b33f_team-pixel3-41.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c846ce1383f3548696_pixel-square-07.png" loading="lazy" id="w-node-fc916818-9e58-1d61-458c-a60a6b632bd5-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eb0472cc946d597afd4_pixel-1-35.png" loading="lazy" id="w-node-ad55b67b-10c4-7043-579b-d4a873d99451-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d319728b7d747_team-pixel2-42.png" loading="lazy" id="w-node-_454a2b41-91c8-c9a3-7b3d-32945c4020e7-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d319728b7d747_team-pixel2-42-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f72a91d319728b7d747_team-pixel2-42.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c92981d32505321f08_pixel-square-14.png" loading="lazy" id="w-node-_6292f626-c7dc-287b-658c-f89cd5ef9820-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62864eaf6eea944d02e311f6_pixel-1-37.png" loading="lazy" id="w-node-_578d9c0d-9b4d-8594-6fb2-e7d94184f43f-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f71a06acc4d376b1fe6_team-pixel2-40.png" loading="lazy" id="w-node-_41d417fa-f2d1-df1c-4897-593bdc656226-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f71a06acc4d376b1fe6_team-pixel2-40-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f71a06acc4d376b1fe6_team-pixel2-40.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/628648c73c44ea31aff0da11_pixel-square-03.png" loading="lazy" id="w-node-_947715f0-4976-adf6-d543-3999d01aae9c-a07db751" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d34986726ea25bc08_team-pixel3-38.png" loading="lazy" id="w-node-c9df22af-b14f-d1a0-9f66-2973ead7d082-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d34986726ea25bc08_team-pixel3-38-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62f2cc9d34986726ea25bc08_team-pixel3-38.png 500w" alt="">
        <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f6fca2a2c9f892b4342_team-pixel2-38.png" loading="lazy" id="w-node-_6c69fd80-aca9-312b-cbd2-b99b1629976c-a07db751" sizes="(max-width: 500px) 100vw, 500px" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f6fca2a2c9f892b4342_team-pixel2-38-p-500.png 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62e40f6fca2a2c9f892b4342_team-pixel2-38.png 500w" alt="">
    </div>
</div>


<div class="footer_section layout_padding">
    <div class="container">
        <div class="input_btn_main">
            <input type="text" class="mail_text" placeholder="Enter your email" name="Enter your email">
            <div class="subscribe_bt"><a href="#">Subscribe</a></div>
        </div>
        <div class="location_main">
            <div class="call_text"><img src="images/call-icon.png"></div>
            <div class="call_text"><a href="#">Call +0 1234567890</a></div>
            <div class="call_text"><img src="images/mail-icon.png"></div>
            <div class="call_text"><a href="#">demo@example.com</a></div>
        </div>
        <div class="social_icon">
            <ul>
                <li><a href="#"><img src="images/fb-icon.png"></a></li>
                <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                <li><a href="#"><img src="images/instagram-icon.png"></a></li>
            </ul>
        </div>
    </div>
</div>




<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>




<script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=62448acf9513136f203e24a4" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/js/webflow.1536ede82.js" type="text/javascript"></script>
<!--[if lte IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
<!-- Bugfix for pagination in tabs: https://discourse.webflow.com/t/pagination-within-tabs/75297/12 -->

<script type="text/javascript" src="js/mdb.min.js"></script>
<!-- Custom scripts -->
<script type="text/javascript"></script>
<script type="text/javascript">

    $(document).ready(function() {

        function activate(tab) {
            // switch all tabs off
            $(".w--current").removeClass(" w--current");

            // switch this tab on
            tab.addClass("w--current");
        }
        if (localStorage) {
            // let's not crash if some user has IE7
            var index = parseInt(localStorage['tab'] || '0');
            activate($('.w-tab-link').eq(index));
        }

        // When a link is clicked
        $(".w-tab-link").click(function() {
            if (localStorage)
                localStorage['tab'] = $(this).index();
            activate($(this));
        });

    });
</script>
<script>
    (function() {
        'use strict';

        document.addEventListener('DOMContentLoaded', function() {
            const searchParams = new URLSearchParams(window.location.search);

            function getCookie(key) {
                return document.cookie.split('; ').find((row)=>row.startsWith(key + '='))?.split('=')[1];
            }

            let date = new Date();
            let expires = date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000);
            // One year

            // Handle offers
            let offer = searchParams.get('offer');

            if (!offer && typeof pageOffer !== 'undefined') {
                //let pageOffer = window.location.pathname.split('/').pop();
                offer = pageOffer;
            }

            if (offer) {
                document.cookie = 'offer=' + offer + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                offer = getCookie('offer');
            }

            if (offer) {
                document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                        let href = link.getAttribute('href').replace("/sign-up/", "/sign-up/home/" + offer + "/");
                        link.setAttribute('href', href);
                    }
                );
            }

            // Handle referrals
            let refCode = searchParams.get('cn_ref_code');
            if (refCode.indexOf('?') !== -1) {
                // Strip breaking appended search params
                refCode = refCode.substring(0, refCode.indexOf('?'));
            }

            if (refCode) {
                document.cookie = 'cn_ref_code=' + refCode + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                refCode = getCookie('cn_ref_code');
            }

            const keys = ['utm_campaign', 'utm_content', 'utm_medium', 'utm_source', 'cn_ref_code', 'fbuy_ref_code'];
            document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                    let href = link.getAttribute('href');

                    keys.forEach((key,index)=>{
                            if (href.indexOf(key) !== -1) {
                                return;
                            }

                            let val = searchParams.get(key);
                            if (val) {
                                href += href.indexOf('?') === -1 ? '?' : '&';
                                if (val.indexOf('?') !== -1) {
                                    // Strip breaking appended search params
                                    val = val.substring(0, val.indexOf('?'));
                                }
                                href += `${key}=${val}`;
                            }
                        }
                    );

                    if (refCode && href.indexOf('cn_ref_code') === -1) {
                        href += (href.indexOf('?') === -1 ? '?' : '&');
                        href += `cn_ref_code=${refCode}`;
                    }

                    link.setAttribute('href', href);
                }
            );
        }, false);

    }());
</script>


</body>

</body>
</html>
<?php /**PATH C:\commision\CompostMates\resources\views/crewmates.blade.php ENDPATH**/ ?>