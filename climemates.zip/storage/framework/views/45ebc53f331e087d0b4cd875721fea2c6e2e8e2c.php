<!doctype html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>ClimeMates</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="/css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="/images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
    <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,900&display=swap" rel="stylesheet">
    <!-- Google Fonts Roboto -->
    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />


    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <style>.active.link-secondary{
            font-weight: bold;
            color:#fff;
        }

    </style>
    <link href="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/css/compostnow.webflow.095f485e0.min.css" rel="stylesheet" type="text/css"/>
    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css"
        rel="stylesheet"
    />


    <!-- Intro settings -->
    <style>
        #intro {
            /* Margin to fix overlapping fixed navbar */
            margin-top: 58px;
        }

        @media (max-width: 991px) {
            #intro {
                /* Margin to fix overlapping fixed navbar */
                margin-top: 45px;
            }
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>


    <div class="bg-dark">
        <nav class="navbar navbar-expand-md navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
            <div class="container-fluid ">
                <a class="navbar-brand" href="/">
                    <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092620741805101096/logo.jpg" alt="..." height="36">
                </a>
                <button class="navbar-toggler collapse" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse collapse d-flex justify-content-end " id="navbarsExample09" style="">
                    <ul class="nav navbar-nav navbar-right ">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                            <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item " href="#">CharMates</a></li>
                                <li><a class="dropdown-item " href="/CompostMates">CompostMates</a></li>
                                <li><a class="dropdown-item" href="#">GardenMates</a></li>
                                <li><a class="dropdown-item " href="#">Next Step</a></li>
                            </ul>

                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                            <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item " href="#">Our Impact</a></li>
                                <li><a class="dropdown-item " href="/OurStory">Our Story</a></li>
                                <li><a class="dropdown-item " href="/CrewMates">Meet the CrewMates</a></li>

                            </ul>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">Blog</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                            <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item " href="#">FAQ</a></li>
                                <li><a class="dropdown-item " href="/contact">Contact action</a></li>
                            </ul>

                        </li>


                    </ul>

                </div>

            </div>
        </nav>

    </div>

<br>
<div> <h2 class="text-center">Home Service</h2></div>


<div class="section wf-section layout_padding">

    <div class="my-contain _4-col impact businesstype banner-images-at-the-top-of-the-pages">
        <img src="https://img.freepik.com/free-photo/woman-having-sustainable-garden-indoors_23-2148999354.jpg?w=740&t=st=1680427172~exp=1680427772~hmac=220042a197baebcfe5f805ebcebdff9ad4e7922d92f8f1dc8d8415516468e54c" loading="lazy" width="575" height="350"  class="image-14"/>
        <div class="img-text biztype">
            <div class="text-container servicepage biztype impact foryourbusiness">
                <h5 class=" _24pt-padding">Easy and Clean</h5>
                <div class="_24pt-padding text-justify">Our home service are well designed for home, villas and apartment. Check out our package and pricing below. </div>
                <div class="my-4">
                    <a href="#package-pricing" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Explore Package and Pricing</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="layout_padding  ">
    <section class="p-4 text-center mt-5 night-fade-gradient">
        <section class="text-center">

            <h3>Composting is easy and clean with us</h3>
            <hr class="my-4 container">
            <!--Grid row-->
            <div class="row d-flex justify-content-center">

                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621614824296540/singup.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>Sign up and get your bucket</h5>

                    <p>
                        Fill your registration form and we will deliver your bucket.
                    </p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621500240101467/bucket.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>Throw your organic waste to the bucket</h5>

                    <p>
                        just throw your organic waste to the bucket
                    </p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621630359998514/truck.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>We Pick it Up</h5>
                    <p>
                        We will pick up your bucket and change with clean one
                    </p>
                </div>

                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621646059282452/bonus.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>Choose your bonus</h5>
                    <p>
                        we provide bonuses for OurMates
                    </p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/100/100565.png?w=740&t=st=1680410520~exp=1680411120~hmac=780172b4f95322f4d065b70e4fe6cfd1b6f12b5c3db04c4f146f67a1847d493d" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>Together, We help the planet!</h5>

                    <p class="text-white"> .</p>
                </div>
                <!--Grid column-->
            </div>
        </section>
    </section>
</div>

<section id="package-pricing" class="text-center">
    <h4 class="mb-4"><strong>Pick your Package!</strong></h4>
    <p class="mb-4">Make your impact</p>

</section>
<div class="container">
    <div class="row ">
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                            Pick-up
                        </p>


                    <p class="d-flex justify-content-center">(One time a week, 1 bucket)</p>

                    <div class="d-flex justify-content-center">
                        <p class="">IDR 100.000</p>
                    </div>
                    <div class="d-flex justify-content-center">
                        <a href="" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Sign up today</a>
                    </div>
                </div>
                <div class="card-footer">
                    <p class="text-uppercase fw-bold" style="font-size: 12px;">What's included</p>
                    <ol class="list-unstyled mb-0 px-4">
                        <p class="my-3 fw-bold text-muted text-center">
                        </p>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>1 clean 20 L bucket</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Pick up plan 1 times a week</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3 text-break"></i><small>Earn bonus (minimum 3 months subscription)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Updated impact data every month</small>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                        Pick-up
                    </p>


                    <p class="d-flex justify-content-center">(Two times a week, 1 bucket)</p>

                    <div class="d-flex justify-content-center">
                        <p class="">IDR 175.000</p>
                    </div>
                    <div class="d-flex justify-content-center">
                        <a href="" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Sign up today</a>
                    </div>
                </div>
                <div class="card-footer">
                    <p class="text-uppercase fw-bold" style="font-size: 12px;">What's included</p>
                    <ol class="list-unstyled mb-0 px-4">
                        <p class="my-3 fw-bold text-muted text-center">
                        </p>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>1 clean 20 L bucket</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Pick up plan 2 times a week</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3 text-break"></i><small>Earn bonus (minimum 3 months subscription)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Updated impact data every month</small>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                        Pick-up
                    </p>


                    <p class="d-flex justify-content-center">(One time every 2 week, 1 bucket)</p>

                    <div class="d-flex justify-content-center">
                        <p class="">IDR 50.000</p>
                    </div>
                    <div class="d-flex justify-content-center">
                        <a href="" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Sign up today</a>
                    </div>
                </div>
                <div class="card-footer">
                    <p class="text-uppercase fw-bold" style="font-size: 12px;">What's included</p>
                    <ol class="list-unstyled mb-0 px-4">
                        <p class="my-3 fw-bold text-muted text-center">
                        </p>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>1 clean 20 L bucket</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Pick up plan 1 times 2 week</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3 text-break"></i><small>Earn bonus (minimum 3 months subscription)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check text-success me-3"></i><small>Updated impact data every month</small>
                        </li>
                    </ol>
                </div>
            </div>
        </div>

    </div>
</div>
<br>
<div class="section _2 wf-section layout_padding">
    <div class="my-contain">
        <h4 id="CurrentServiceAreas" class="h4 center _24pt-padding">Current Compost Service Area</h4>
        <div class="w-layout-grid areas-grid foryourhome">
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home"></div>

            </div>
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home">Ubud, Gianyar Regency, Bali</div>

            </div>
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home"></div>

            </div>
        </div>
    </div>
</div>

<div class="container layout_padding" id="list-compost">
    <section class="text-center">
        <h4 class="mb-4"><strong>Compostable Lists </strong></h4>


    </section>
    <div class="row d-flex justify-content-center">
        <div class="col-md-4Yes, compostable: col-lg-4 mb-5">
            <div class="card">

                <div class="card-body">

                    <p class="card-subtitle d-flex justify-content-center">Yes, compostable: </p>
                    <hr class="border-dark w-25 mx-auto">
                    <p class="mb-3">
                    <ol class="list-unstyled mb-0 px-4">

                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Any part of fruit and vegetable scraps</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Meat (with or without bones)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Cooked Food leftover</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Organic food cover (Banana leaves)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Coffee grounds and filters</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Tea Bags</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Eggshells</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Nut shells</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Yard waste (grass clippings, leaves, and twigs)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Paper (newspaper, uncoated paper, and cardboard)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Wood chips and sawdust (untreated)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Cotton and wool scraps (cut into small pieces)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Hair and fur (human and pet)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Hay and straw (make sure they are free from pesticides and herbicides)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Plant-based food (such as bread and pasta)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Seaweed and kelp</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Fireplace ashes (in small quantities)</small>
                        </li>
                    </ol>
                    </p>

                </div>
            </div>
        </div>

        <div class="col-lg-2 col-lg-4 mb-5">
            <div class="card">

                <div class="card-body">

                    <p class="card-subtitle d-flex justify-content-center">Not Accepted </p>
                    <hr class="border-dark w-25 mx-auto">
                    <p class="mb-3">
                    <ol class="list-unstyled mb-0 px-4">

                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Plastic</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Styrofoam</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Aluminum foil</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Coated paper</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Clams, oysters, mussels (basically rocks)</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Candles, synthetic corks and gum</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Artificial flowers and plants</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Rugs</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Cigarette butts, tobacco</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Floss, q-tips, baby wipes</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Dryer lint, dryer sheets</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Items labeled recyclable</small>
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-angle-right text-success me-3"></i><small>Items labeled biodegradable (meaningless)</small>
                        </li>
                    </ol>
                    </p>

                </div>
            </div>
        </div>
    </div>
</div>

    <div class="footer_section layout_padding">
        <div class="container">

            <div class="location_main">
                <div class="call_text"><img src=https://themewagon.github.io/a-world/images/call-icon.png></div>
                <div class="call_text"><a href="#">Call +0 1234567890</a></div>
                <div class="call_text"><img src=https://themewagon.github.io/a-world/images/mail-icon.png></div>
                <div class="call_text"><a href="#">demo@example.com</a></div>
            </div>
            <div class="social_icon">
                <ul>
                    <li><a href="#"><img src="images/fb-icon.png"></a></li>
                    <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                    <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                    <li><a href="#"><img src="images/instagram-icon.png"></a></li>
                </ul>
            </div>
        </div>
    </div>







<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>




<script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=62448acf9513136f203e24a4" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/js/webflow.1536ede82.js" type="text/javascript"></script>
<!--[if lte IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
<!-- Bugfix for pagination in tabs: https://discourse.webflow.com/t/pagination-within-tabs/75297/12 -->

<script type="text/javascript" src="js/mdb.min.js"></script>
<!-- Custom scripts -->
<script type="text/javascript"></script>
<script type="text/javascript">

    $(document).ready(function() {

        function activate(tab) {
            // switch all tabs off
            $(".w--current").removeClass(" w--current");

            // switch this tab on
            tab.addClass("w--current");
        }
        if (localStorage) {
            // let's not crash if some user has IE7
            var index = parseInt(localStorage['tab'] || '0');
            activate($('.w-tab-link').eq(index));
        }

        // When a link is clicked
        $(".w-tab-link").click(function() {
            if (localStorage)
                localStorage['tab'] = $(this).index();
            activate($(this));
        });

    });
</script>
<script>
    (function() {
        'use strict';

        document.addEventListener('DOMContentLoaded', function() {
            const searchParams = new URLSearchParams(window.location.search);

            function getCookie(key) {
                return document.cookie.split('; ').find((row)=>row.startsWith(key + '='))?.split('=')[1];
            }

            let date = new Date();
            let expires = date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000);
            // One year

            // Handle offers
            let offer = searchParams.get('offer');

            if (!offer && typeof pageOffer !== 'undefined') {
                //let pageOffer = window.location.pathname.split('/').pop();
                offer = pageOffer;
            }

            if (offer) {
                document.cookie = 'offer=' + offer + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                offer = getCookie('offer');
            }

            if (offer) {
                document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                        let href = link.getAttribute('href').replace("/sign-up/", "/sign-up/home/" + offer + "/");
                        link.setAttribute('href', href);
                    }
                );
            }

            // Handle referrals
            let refCode = searchParams.get('cn_ref_code');
            if (refCode.indexOf('?') !== -1) {
                // Strip breaking appended search params
                refCode = refCode.substring(0, refCode.indexOf('?'));
            }

            if (refCode) {
                document.cookie = 'cn_ref_code=' + refCode + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                refCode = getCookie('cn_ref_code');
            }

            const keys = ['utm_campaign', 'utm_content', 'utm_medium', 'utm_source', 'cn_ref_code', 'fbuy_ref_code'];
            document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                    let href = link.getAttribute('href');

                    keys.forEach((key,index)=>{
                            if (href.indexOf(key) !== -1) {
                                return;
                            }

                            let val = searchParams.get(key);
                            if (val) {
                                href += href.indexOf('?') === -1 ? '?' : '&';
                                if (val.indexOf('?') !== -1) {
                                    // Strip breaking appended search params
                                    val = val.substring(0, val.indexOf('?'));
                                }
                                href += `${key}=${val}`;
                            }
                        }
                    );

                    if (refCode && href.indexOf('cn_ref_code') === -1) {
                        href += (href.indexOf('?') === -1 ? '?' : '&');
                        href += `cn_ref_code=${refCode}`;
                    }

                    link.setAttribute('href', href);
                }
            );
        }, false);

    }());
</script>



</body>
</html>
<?php /**PATH C:\commision\CompostMates\resources\views/home.blade.php ENDPATH**/ ?>