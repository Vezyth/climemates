<!doctype html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>ClimeMates</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="/css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="/images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
    <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,900&display=swap" rel="stylesheet">
    <!-- Google Fonts Roboto -->
    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />


    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <style>.active.link-secondary{
            font-weight: bold;
            color:#fff;
        }

    </style>
    <link href="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/css/compostnow.webflow.095f485e0.min.css" rel="stylesheet" type="text/css"/>
    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css"
        rel="stylesheet"
    />


    <!-- Intro settings -->
    <style>
        #intro {
            /* Margin to fix overlapping fixed navbar */
            margin-top: 58px;
        }

        @media (max-width: 991px) {
            #intro {
                /* Margin to fix overlapping fixed navbar */
                margin-top: 45px;
            }
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>


<div class="bg-dark">
    <nav class="navbar navbar-expand-md navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
        <div class="container-fluid ">
            <a class="navbar-brand" href="/">
                <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092620741805101096/logo.jpg" alt="..." height="36">
            </a>



            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNav">
                <ul class="nav navbar-nav navbar-right ">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">CharMates</a></li>
                            <li><a class="dropdown-item " href="/CompostMates">CompostMates</a></li>
                            <li><a class="dropdown-item" href="#">GardenMates</a></li>
                            <li><a class="dropdown-item " href="#">Next Step</a></li>
                        </ul>

                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">Our Impact</a></li>
                            <li><a class="dropdown-item " href="/OurStory">Our Story</a></li>
                            <li><a class="dropdown-item " href="/CrewMates">Meet the CrewMates</a></li>

                        </ul>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#">Blog</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                        <ul class="dropdown-menu bg-transparent border border-dark" aria-labelledby="dropdown09">
                            <li><a class="dropdown-item " href="#">FAQ</a></li>
                            <li><a class="dropdown-item " href="/contact">Contact action</a></li>
                        </ul>

                    </li>


                </ul>
            </div>


        </div>
    </nav>

</div>

<br>
<div> <h2 class="text-center">Business Service</h2></div>


<div class="section wf-section layout_padding">

    <div class="my-contain _4-col impact businesstype banner-images-at-the-top-of-the-pages">
        <img src="https://img.freepik.com/free-photo/woman-having-sustainable-garden-indoors_23-2148999354.jpg?w=740&t=st=1680427172~exp=1680427772~hmac=220042a197baebcfe5f805ebcebdff9ad4e7922d92f8f1dc8d8415516468e54c" loading="lazy" width="575" height="350"  class="image-14"/>
        <div class="img-text biztype">
            <div class="text-container servicepage biztype impact foryourbusiness">
                <h5 class=" _24pt-padding">Help your business more Sustainable!</h5>
                <div class="_24pt-padding text-justify">Our business service are designed to help any kind Business to be more sustainable. Check out our package and pricing below.</div>
                <div class="my-4">
                    <a href="#package-pricing" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Explore Package and Pricing</a>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="layout_padding container ">
    <section class="p-4 text-center mt-5 night-fade-gradient">
        <section class="text-center">

            <h3>What we provide to help achieve your goal</h3>
            <hr class="my-4 container">
            <!--Grid row-->
            <div class="row d-flex justify-content-center">

                <div class="col-lg-4 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/62/62991.png?w=740&t=st=1680572982~exp=1680573582~hmac=e8f16e83b6d4e4acd0740718f42cbc1e3640fbd956a8ae9f8919a3c108bb9a72" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>1.	Clean container</h5>


                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-4 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/59/59032.png?w=740&t=st=1680573044~exp=1680573644~hmac=a09c44145472ece703b38869e340abb1ffef9c1305e65404bf6f2f5e6e071e3d" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>2.	Monthly Impact Report</h5>


                </div>
                <div class="col-lg-4 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/1172/1172274.png?w=740&t=st=1680572775~exp=1680573375~hmac=160661375b810e915a542e330f2f68f65f32a003b3a12e16dfe4f9d49b655c2b" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>3.	Commercial Support/Marketing Support</h5>

                </div>


                <!--Grid column-->
            </div>
        </section>
    </section>
</div>


<div class="layout_padding">
    <section class="p-4 text-center mt-5 night-fade-gradient">
        <section class="text-center">

            <h3>Composting is easy and clean with us</h3>
            <hr class="my-4 container">
            <!--Grid row-->
            <div class="row d-flex justify-content-center">

                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621614824296540/singup.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>Sign up and get your bucket</h5>

                    <p>
                        Fill your registration form and we will deliver your bucket.
                    </p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621500240101467/bucket.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>Throw your organic waste to the bucket</h5>

                    <p>
                        just throw your organic waste to the bucket
                    </p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621630359998514/truck.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>We Pick it Up</h5>
                    <p>
                        We will pick up your bucket and change with clean one
                    </p>
                </div>

                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn.discordapp.com/attachments/852892372072923147/1092621646059282452/bonus.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>Choose your bonus</h5>
                    <p>
                        we provide bonuses for OurMates
                    </p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/100/100565.png?w=740&t=st=1680410520~exp=1680411120~hmac=780172b4f95322f4d065b70e4fe6cfd1b6f12b5c3db04c4f146f67a1847d493d" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>Together, We help the planet!</h5>

                    <p class="text-white"> .</p>
                </div>
                <!--Grid column-->
            </div>
        </section>
    </section>
</div>

<section id="package-pricing" class="text-center">
    <h4 class="mb-4"><strong>Pricing Plans</strong></h4>
    <p class="mb-4">Make your impact</p>

</section>
<div class="container">
    <div class="row ">
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                        Small Business
                    </p>
                    <br>
                    <h5 class="card-subtitle d-flex justify-content-center">1x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">2x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">3x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                        Medium Business
                    </p>
                    <br>
                    <h5 class="card-subtitle d-flex justify-content-center">1x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">2x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">3x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="mx-2 card-body ">
                    <p class="h4 fw-bold d-flex justify-content-center ">
                        Large Business
                    </p>
                    <br>
                    <h5 class="card-subtitle d-flex justify-content-center">1x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">2x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                    <hr>
                    <h5 class="card-subtitle d-flex justify-content-center">3x every week </h5>
                    <h5 class="text-center">IDR XXX.XXX/Month</h5>
                </div>
            </div>
        </div>

    </div>
</div>
<br>

<div id="main-form" class="section form wf-section">
    <div id="2" class="my-contain form">
        <div class="img-quote img-quote-wrapper  main v2"> <img src="https://img.freepik.com/free-photo/person-planting-tree-countryside_23-2149401200.jpg?size=626&ext=jpg" style=" height: 100%"></div>
        <div id="ServiceBusiness-Form" class="form-wrapper servicebusiness mobilepage">
            <h5 class="h5">Let &#x27;s talk compost!</h5>
            <div class="subtitle biztype normal">If you &#x27;re interested in composting services, please fill out this form and someone from our team will be in touch shortly.</div>
            <div class="form-container">
                <div class="form-block w-form">
                    <?php if(Session::has('message_sent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('message_sent')); ?>

                        </div>
                    <?php endif; ?>
                    <form id="wf-form-Service-Form" name="wf-form-Service-Form" data-name="Service Form" method="POST" action="<?php echo e(route('business.send')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="First-Name-2" class="subtitle form-label">First Name</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="fname" data-name="First Name" placeholder="" id="First-Name-2" required=""/>
                            </div>
                            <div class="field-wrapper">
                                <label for="Last-Name-2" class="subtitle form-label">Last Name</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="lname" data-name="Last Name" placeholder="" id="Last-Name-2" required=""/>
                            </div>
                        </div>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="Business-Name" class="subtitle form-label">Business Name</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="bname" data-name="Business Name" placeholder="" id="Business-Name" required=""/>
                            </div>
                            <div class="field-wrapper">
                                <label for="Phone-number" class="subtitle form-label">Phone Number</label>
                                <input type="tel" class="text-field w-input" maxlength="256" name="phone" data-name="Phone number" placeholder="" id="Phone-number" required=""/>
                            </div>
                        </div>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="Business-Type" class="subtitle form-label">Business Type</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="btype" data-name="City 2" placeholder="" id="City-2" required=""/>
                            </div>
                            <div class="field-wrapper">
                                <label for="Email-2" class="subtitle form-label">E-mail Address</label>
                                <input type="email" class="text-field w-input" maxlength="256" name="email" data-name="Email" placeholder="" id="Email-2" required=""/>
                            </div>
                        </div>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="Address-2" class="subtitle form-label">Address</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="address" data-name="Address 2" placeholder="" id="Address-2" required=""/>
                            </div>
                            <div class="field-wrapper">
                                <label for="City-2" class="subtitle form-label">City</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="city" data-name="City 2" placeholder="" id="City-2" required=""/>
                            </div>
                        </div>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="State-2" class="subtitle form-label">State</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="state" data-name="City 2" placeholder="" id="City-2" required=""/>
                            </div>
                            <div class="field-wrapper">
                                <label for="Zip" class="subtitle form-label">Zip Code</label>
                                <input type="number" class="text-field w-input" maxlength="5" name="zcode" data-name="Zip" placeholder="" id="Zip" required=""/>
                            </div>
                        </div>
                        <div class="fields">
                            <div class="field-wrapper">
                                <label for="Heard-From" class="subtitle form-label">How did you hear about us?</label>
                                <input type="text" class="text-field w-input" maxlength="256" name="message" data-name="heard-from" placeholder="" id="Heard-From" required=""/>
                            </div>
                        </div>
                        <div data-sitekey="6LcRGEQhAAAAAOq_W0jPz6oTWGwZcNRGp4dQeRG0" class="w-form-formrecaptcha g-recaptcha g-recaptcha-error g-recaptcha-disabled"></div>
                        <div class="fields">
                            <input type="submit" value="SUBMIT FORM" data-wait="Please wait..." class="cta-btn label outline-btn teal fields w-button"/>
                        </div>
                    </form>
                    <div id="success" class="success-message w-form-done">
                        <div class="text-block-7">Thank you for your submission! You’ll receive an email from us shortly. We look forward to talking compost with you!</div>
                    </div>
                    <div class="error-message w-form-fail">
                        <div class="error">Oops! Something went wrong while submitting the form. Please try again.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section _2 wf-section layout_padding">
    <div class="my-contain">
        <h4 id="CurrentServiceAreas" class="h4 center _24pt-padding">Current Compost Service Area</h4>
        <div class="w-layout-grid areas-grid foryourhome">
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home"></div>

            </div>
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home">Ubud, Gianyar Regency, Bali</div>

            </div>
            <div  id="w-node-_89eb9f68-a012-cec3-bcdb-dd5e52d8c382-75c31d7c" class="areas-contain d-flex justify-content-center">
                <div class="area-title home"></div>

            </div>
        </div>
    </div>
</div>

<div class="layout_padding container">
    <H5 class="text-center">Our Sponsors:</H5>
    <br>
    <p class="text-center">this could be you</p>
</div>





<div class="footer_section layout_padding">
    <div class="container">

        <div class="location_main">
            <div class="call_text"><img src=https://themewagon.github.io/a-world/images/call-icon.png></div>
            <div class="call_text"><a href="#">Call +0 1234567890</a></div>
            <div class="call_text"><img src=https://themewagon.github.io/a-world/images/mail-icon.png></div>
            <div class="call_text"><a href="#">demo@example.com</a></div>
        </div>
        <div class="social_icon">
            <ul>
                <li><a href="#"><img src="images/fb-icon.png"></a></li>
                <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                <li><a href="#"><img src="images/instagram-icon.png"></a></li>
            </ul>
        </div>
    </div>
</div>




<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>




<script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=62448acf9513136f203e24a4" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/js/webflow.1536ede82.js" type="text/javascript"></script>
<!--[if lte IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
<!-- Bugfix for pagination in tabs: https://discourse.webflow.com/t/pagination-within-tabs/75297/12 -->

<script type="text/javascript" src="js/mdb.min.js"></script>
<!-- Custom scripts -->
<script type="text/javascript"></script>
<script type="text/javascript">

    $(document).ready(function() {

        function activate(tab) {
            // switch all tabs off
            $(".w--current").removeClass(" w--current");

            // switch this tab on
            tab.addClass("w--current");
        }
        if (localStorage) {
            // let's not crash if some user has IE7
            var index = parseInt(localStorage['tab'] || '0');
            activate($('.w-tab-link').eq(index));
        }

        // When a link is clicked
        $(".w-tab-link").click(function() {
            if (localStorage)
                localStorage['tab'] = $(this).index();
            activate($(this));
        });

    });
</script>
<script>
    (function() {
        'use strict';

        document.addEventListener('DOMContentLoaded', function() {
            const searchParams = new URLSearchParams(window.location.search);

            function getCookie(key) {
                return document.cookie.split('; ').find((row)=>row.startsWith(key + '='))?.split('=')[1];
            }

            let date = new Date();
            let expires = date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000);
            // One year

            // Handle offers
            let offer = searchParams.get('offer');

            if (!offer && typeof pageOffer !== 'undefined') {
                //let pageOffer = window.location.pathname.split('/').pop();
                offer = pageOffer;
            }

            if (offer) {
                document.cookie = 'offer=' + offer + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                offer = getCookie('offer');
            }

            if (offer) {
                document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                        let href = link.getAttribute('href').replace("/sign-up/", "/sign-up/home/" + offer + "/");
                        link.setAttribute('href', href);
                    }
                );
            }

            // Handle referrals
            let refCode = searchParams.get('cn_ref_code');
            if (refCode.indexOf('?') !== -1) {
                // Strip breaking appended search params
                refCode = refCode.substring(0, refCode.indexOf('?'));
            }

            if (refCode) {
                document.cookie = 'cn_ref_code=' + refCode + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                refCode = getCookie('cn_ref_code');
            }

            const keys = ['utm_campaign', 'utm_content', 'utm_medium', 'utm_source', 'cn_ref_code', 'fbuy_ref_code'];
            document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                    let href = link.getAttribute('href');

                    keys.forEach((key,index)=>{
                            if (href.indexOf(key) !== -1) {
                                return;
                            }

                            let val = searchParams.get(key);
                            if (val) {
                                href += href.indexOf('?') === -1 ? '?' : '&';
                                if (val.indexOf('?') !== -1) {
                                    // Strip breaking appended search params
                                    val = val.substring(0, val.indexOf('?'));
                                }
                                href += `${key}=${val}`;
                            }
                        }
                    );

                    if (refCode && href.indexOf('cn_ref_code') === -1) {
                        href += (href.indexOf('?') === -1 ? '?' : '&');
                        href += `cn_ref_code=${refCode}`;
                    }

                    link.setAttribute('href', href);
                }
            );
        }, false);

    }());
</script>


</body>

</body>
</html>
<?php /**PATH C:\commision\CompostMates\resources\views/business.blade.php ENDPATH**/ ?>