<!DOCTYPE html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>ClimeMates</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="/css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="/images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
<!-- header section start -->
<div class="header_section ">
    <div class="header_main">
        <nav class="navbar navbar-expand-lg navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
            <div class="container-fluid ">
                <a class="navbar-brand" href="/">
                    <img src="images/logo.jpg" alt="..." height="36">
                </a>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse collapse d-flex justify-content-end " id="navbarsExample09" style="">
                    <ul class="nav navbar-nav navbar-right ">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white " href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">CharMates</a></li>
                                <li><a class="dropdown-item text-white" href="/CompostMates">CompostMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">GardenMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">Next Step</a></li>
                            </ul>

                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">Our Impact</a></li>
                                <li><a class="dropdown-item text-white" href="/OurStory">Our Story</a></li>
                                <li><a class="dropdown-item text-white" href="/CrewMates">Meet the CrewMates</a></li>

                            </ul>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">Blog</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">FAQ</a></li>
                                <li><a class="dropdown-item text-white" href="/contact">Contact action</a></li>
                            </ul>

                        </li>


                    </ul>

                </div>

            </div>
        </nav>

    </div>
    <!-- banner section start -->
    <div class="banner_section layout_padding">
        <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="container">
                        <h1 class="banner_taital">ClimeMates</h1>
                        <p class="banner_text">Local Collaboration of Scientist and Farmer to combat climates problem, Environmental Startup
                            Based in Bali, Indonesia
                        </p>


                    </div>
                </div>
                <div class="carousel-item">
                    <div class="container">
                        <h1 class="banner_taital">ClimeMates</h1>
                        <p class="banner_text">Local Collaboration of Scientist and Farmer to combat climates problem, Environmental Startup
                            Based in Bali, Indonesia
                        </p>

                    </div>
                </div>
                <div class="carousel-item">
                    <div class="container">
                        <h1 class="banner_taital">ClimeMates</h1>
                        <p class="banner_text">Local Collaboration of Scientist and Farmer to combat climates problem, Environmental Startup
                            Based in Bali, Indonesia
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner section end -->
</div>

<div class="choose_section layout_padding">
    <div class="container">
        <h1 class="choose_taital">Together we make an Impact.</h1>
        <p class="choose_text h5 font-weight-normal text-justify">Climate change is one of the most pressing environmental issues facing the world today, and agriculture is both a major contributor to greenhouse gas and heavily impacted by the effects of climate change. Despite the challenges, it is essential for scientists and farmers to work together to address issues related to agriculture and the environment. By collaborating, we can share knowledge, expertise, and resources to develop solutions that are scientifically sound, practical, and effective in the real world.</p>

    </div>
</div>
<!-- header section end -->
<!-- services section start -->
<div class="services_section layout_padding">
    <div class="container">
        <h1 class="services_taital">Our Projects </h1>
        <div class="services_section_2">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card">
                        <img src="images/biochar.png" class=" img-fluid" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">CharMates</h5>
                            <p class="card-text  font-weight-normal">Capture emissions, lock it, and turn it into soil additive, a real solution for combating climate change.</p>
                            <div class="btn_main"><a href="#">More Details</a></div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <img src="images/compost.png" class="img-fluid" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">CompostMates</h5>
                            <p class="card-text font-weight-normal">Organic waste collection service, the easiest way for homes and business to turn organic waste into nutrient rich compost.</p>
                            <div class="btn_main"><a href="/CompostMates">More Details</a></div>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <div class="card">
                        <img src="images/garden.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">GrowMates</h5>
                            <p class="card-text font-weight-normal">Problem solving product for a healthier garden. No Chemical, Healthier.</p>
                            <p class="text-white h4">.</p>
                            <div class="btn_main"><a href="#">More Details</a></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- services section end -->
<!-- about section start -->
<!-- blog section end -->
<!-- client section start -->

<!-- client section start -->
<!-- choose section start -->
<div class="choose_section layout_padding">
    <div class="container">
        <h1 class="choose_taital">
            What can we do to help you?
        </h1>
        <p class="customer_text text-center">What can we do to help you?</p>
        <p class="customer_text text-center">Facing an environmental problem?</p>
        <p class="customer_text text-center" >Want to reduce your impact to the ecosystem?</p>
        <p class="customer_text text-center" >Want to start helping the earth?</p>



        <div class="read_bt_1"><a href="#">Give us a go!</a></div>

    </div>
</div>
<!-- choose section end -->
<!-- footer section start -->
<div class="footer_section layout_padding">
    <div class="container">

        <div class="location_main">
            <div class="call_text"><img src="images/call-icon.png"></div>
            <div class="call_text"><a href="#">Call +0 1234567890</a></div>
            <div class="call_text"><img src="images/mail-icon.png"></div>
            <div class="call_text"><a href="#">demo@example.com</a></div>
        </div>
        <div class="social_icon">
            <ul>
                <li><a href="#"><img src="images/fb-icon.png"></a></li>
                <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                <li><a href="#"><img src="images/instagram-icon.png"></a></li>
            </ul>
        </div>
    </div>
</div>
<!-- footer section end -->
<!-- copyright section start -->

<!-- copyright section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>

</html>
<?php /**PATH C:\commision\CompostMates\resources\views/welcome.blade.php ENDPATH**/ ?>