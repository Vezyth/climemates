<!DOCTYPE html>
<html lang="en">

<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>A World</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
</head>

<body>
<!-- header section start -->
<div class="header_section ">
    <div class="header_main">
        <nav class="navbar navbar-expand-lg navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
            <div class="container-fluid ">
                <a class="navbar-brand" href="/">
                    <img src="images/logo.jpg" alt="..." height="36">
                </a>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse collapse d-flex justify-content-end " id="navbarsExample09" style="">
                    <ul class="nav navbar-nav navbar-right ">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white " href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">CharMates</a></li>
                                <li><a class="dropdown-item text-white" href="/CompostMates">CompostMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">GardenMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">Next Step</a></li>
                            </ul>

                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">Our Impact</a></li>
                                <li><a class="dropdown-item text-white" href="#">Our Story</a></li>
                                <li><a class="dropdown-item text-white" href="#">Meet the CrewMates</a></li>

                            </ul>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">Blog</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">FAQ</a></li>
                                <li><a class="dropdown-item text-white" href="/contact">Contact action</a></li>
                            </ul>

                        </li>


                    </ul>

                </div>

            </div>
        </nav>

    </div>
    <!-- banner section start -->

    <!-- banner section end -->
</div>

<div class="choose_section layout_padding">
    <div class="container">
        <h1 class="choose_taital">Website Is Under Construction</h1>

        <div class="read_bt_1"><a href="/">Back to Home page</a></div>
    </div>
</div>

<div class="footer_section layout_padding">
    <div class="container">

        <div class="location_main">
            <div class="call_text"><img src="images/call-icon.png"></div>
            <div class="call_text"><a href="#">Call +01 1234567890</a></div>
            <div class="call_text"><img src="images/mail-icon.png"></div>
            <div class="call_text"><a href="#">demo@gmail.com</a></div>
        </div>
        <div class="social_icon">
            <ul>
                <li><a href="#"><img src="images/fb-icon.png"></a></li>
                <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                <li><a href="#"><img src="images/instagram-icon.png"></a></li>
            </ul>
        </div>
    </div>
</div>
<!-- footer section end -->
<!-- copyright section start -->

<!-- copyright section end -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
</body>

</html>
<?php /**PATH C:\commision\CompostMates\resources\views/story.blade.php ENDPATH**/ ?>