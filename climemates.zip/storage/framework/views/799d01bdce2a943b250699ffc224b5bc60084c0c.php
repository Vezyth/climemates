<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<h1>Business Message</h1>
<p>First Name                   : <?php echo e($details['fname']); ?></p>
<p>Last Name                    : <?php echo e($details['lname']); ?></p>
<p>Phone Number                 : <?php echo e($details['phone']); ?></p>
<p>Business Type                : <?php echo e($details['btype']); ?></p>
<p>Email                        : <?php echo e($details['email']); ?></p>
<p>Address                      : <?php echo e($details['address']); ?></p>
<p>City                         : <?php echo e($details['city']); ?></p>
<p>State                        : <?php echo e($details['state']); ?></p>
<p>Zip Code                     : <?php echo e($details['zcode']); ?></p>
<p>How did you hear about us    : <?php echo e($details['message']); ?></p>
</body>
</html>
<?php /**PATH C:\commision\CompostMates\resources\views/email/BusinessEmail.blade.php ENDPATH**/ ?>