<!doctype html>
<html lang="en">
<head>
    <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- site metas -->
    <title>ClimeMates</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="/css/responsive.css">
    <!-- fevicon -->
    <link rel="icon" href="/images/fevicon.png" type="image/gif" />
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="/css/jquery.mCustomScrollbar.min.css">
    <!-- Tweaks for older IEs-->
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700|Righteous&display=swap" rel="stylesheet">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css"
          media="screen">
    <link rel="icon" href="img/mdb-favicon.ico" type="image/x-icon" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,900&display=swap" rel="stylesheet">
    <!-- Google Fonts Roboto -->
    <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap"
    />


    <!-- MDB -->
    <link rel="stylesheet" href="css/mdb.min.css" />
    <style>.active.link-secondary{
            font-weight: bold;
            color:#fff;
        }

    </style>
    <link href="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/css/compostnow.webflow.095f485e0.min.css" rel="stylesheet" type="text/css"/>
    <link
        href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css"
        rel="stylesheet"
    />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<body>
<div class="header_section ">
    <div class="header_main">
        <nav class="navbar navbar-expand-lg navbar-dark shadow-5-strong" aria-label="Eleventh navbar example">
            <div class="container-fluid ">
                <a class="navbar-brand" href="/">
                    <img src="images/logo.jpg" alt="..." height="36">
                </a>
                <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="navbar-collapse collapse d-flex justify-content-end " id="navbarsExample09" style="">
                    <ul class="nav navbar-nav navbar-right ">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white " href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Projects</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">CharMates</a></li>
                                <li><a class="dropdown-item text-white" href="/CompostMates">CompostMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">GardenMates</a></li>
                                <li><a class="dropdown-item text-white" href="#">Next Step</a></li>
                            </ul>

                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">About Us</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">Our Impact</a></li>
                                <li><a class="dropdown-item text-white" href="/OurStory">Our Story</a></li>
                                <li><a class="dropdown-item text-white" href="/CrewMates">Meet the CrewMates</a></li>

                            </ul>

                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">Blog</a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-white" href="#" id="dropdown09" data-bs-toggle="dropdown" aria-expanded="false">Help Center</a>
                            <ul class="dropdown-menu bg-transparent border border-white" aria-labelledby="dropdown09">
                                <li><a class="dropdown-item text-white" href="#">FAQ</a></li>
                                <li><a class="dropdown-item text-white" href="/contact">Contact action</a></li>
                            </ul>

                        </li>


                    </ul>

                </div>

            </div>
        </nav>

    </div>
    <!-- banner section start -->
    <div class="banner_section layout_padding">

            <div class="container d-flex align-items-center justify-content-center text-center h-100">
                <div class="text-white">
                    <h1 class="banner_taital">CompostMates
                        </h1>
                    <h5 class="text-white">More future, with less emissions, Let’s compost with us.</h5>
                    <h5 class="text-white">Offering the easiest way for everyone to turn organic waste into nutrient rich compost.</h5>
                    <div class="mt-4">
                        <a href="/CompostMates/HomeService" class="btn btn-outline-light" tabindex="-1" role="button">Home Services</a>
                        <a href="/CompostMates/BusinessService" class="btn btn-outline-light ml-4" tabindex="-1" role="button">Business Services</a>

                    </div>
                </div>
            </div>

    </div>
    <!-- banner section end -->
</div>

<div class="text-white">asds</div>

<div class="layout_padding  ">
    <section class="p-4 text-center mt-5 night-fade-gradient">
        <section class="text-center">

            <h3>Composting made easy and clean with CompostMates</h3>
            <hr class="my-4 container">
            <!--Grid row-->
            <div class="row d-flex justify-content-center">

                    <div class="col-lg-2 col-md-4 mb-4">
                        <a>
                            <img src="images/singup.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                        </a>

                        <h5>Sign up and get your bucket</h5>

                        <p>
                            Fill your registration form and we will deliver your bucket.
                        </p>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-2 col-md-4 mb-4">
                        <a>
                            <img src="images/bucket.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                        </a>
                        <h5>Throw your organic waste to the bucket</h5>

                        <p>
                            Throw organic waste (see list <a href="/CompostMates/HomeService#list-compost">here</a>) to the bucket.
                        </p>
                    </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="images/truck.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>We Pick it and Change </h5>
                    <p>
                        We will pick up the bucket and change with clean bucket.
                    </p>
                </div>

                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="images/bonus.png" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>
                    <h5>Choose your bonus</h5>
                    <p>
                        We have range of bonuses for you to choose, not just compost.
                    </p>
                </div>
                <div class="col-lg-2 col-md-4 mb-4">
                    <a>
                        <img src="https://cdn-icons-png.flaticon.com/512/100/100565.png?w=740&t=st=1680410520~exp=1680411120~hmac=780172b4f95322f4d065b70e4fe6cfd1b6f12b5c3db04c4f146f67a1847d493d" class="mb-4" alt="Picture" style="width:auto;max-width:50%">
                    </a>

                    <h5>Together, We help the planet!</h5>

                    <p class="text-white"> .</p>
                </div>
                <!--Grid column-->
            </div>
        </section>
    </section>
</div>




<div class="container layout_padding mb-4">
    <h4 class="h4">Our Composting is compatible with any type of kitchen.</h4>
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Home</button>
        </li>

        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Business</button>
        </li>
    </ul>
    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <div class="row">
                <div class="col-md-6">
                    We offer twice a  weekly and bi-weekly pick-up Even On Call services at your doorstep.

                    <div class="my-4">
                        <a href="/CompostMates/HomeService" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Explore Home Services</a>
                    </div>

                </div>

                <div class="col-md-6 padding_right_0">
                    <div class="img-quote-wrapper">
                        <div class="quote-tab-container">
                            <div class="subtitle tab-quote home">“CompostNow is a great company! The site is easy to use and the pickups are very reliable. I love seeing my impact reports and decreasing my garbage volume.”</div>
                            <div class="caption">Paige D.</div>
                        </div>
                        <img width="400" height="400" src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch.jpg" loading="lazy" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch-p-500.jpeg 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch-p-800.jpeg 800w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch-p-1080.jpeg 1080w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch-p-1600.jpeg 1600w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695ad2cfa125f3b58f6640_house-porch.jpg 1650w" sizes="(max-width: 991px) 100vw, 425px" alt="" class="img-tab"/>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
            <div class="row">
                <div class="col-md-6">
                    We service a range of industries including offices, restaurants, coffee shops, event centers, and Beach club.

                    <div class="my-4">
                        <a href="/CompostMates/BusinessService" class="cta-btn label outline-btn teal center w-button d-inline-flex p-2 padding-left">Explore Business Services</a>
                    </div>
                </div>
                <div class="col-md-6 padding_right_0">
                    <div class="img-quote-wrapper">
                        <div class="quote-tab-container">
                            <div class="subtitle tab-quote home">“I &#x27;m proud to work for a company that is conscious of its eco-footprint. This service helps me take sustainability actions on a daily basis... in a super easy way.”</div>
                            <div class="caption">Stephanie S.</div>
                        </div>
                        <img width="400" height="400" src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office.jpg" loading="lazy" srcset="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office-p-500.jpeg 500w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office-p-800.jpeg 800w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office-p-1080.jpeg 1080w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office-p-1600.jpeg 1600w, https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62695a604cfca0fd7f187673_office.jpg 1650w" sizes="(max-width: 991px) 100vw, 425px" alt="" class="img-tab"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br class="layout_padding">


<!-- behind-bin-home itu imagenya -->
<div class="my-4 section behind-bin-home home wf-section">
    <div class="my-contain homesection3">
        <div class="text-wrapper-behind-bin homesection3">
            <h5 class=" text-white text-justify font-weight-normal">Soil health is the essence of the wellbeing of every living thing. But sadly, we are facing a problem in form of soil degradation and nutrient depletion because of our dependency to chemical fertilizer and pesticides.</h5>
            <h6 class=" text-white text-justify font-weight-normal mb-5 ">Composting can be the solution to restoring soil health and combats climate change while also help creating local jobs.</h6>

            <a href="/OurStory" class="cta-btn label outline-btn w-button">Our Story</a>
        </div>
    </div>
</div>

<div class="section wf-section">
    <div class="my-contain impact-home _2">
        <h3 class="text-center mb-4">One Small Step towards Better Future</h3>
        <br>
        <div class="info-wrapper _2 d-flex align-items-center justify-content-center">



            <div class="boxes-wrap">
                <div class="box light-teal">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62448eaf898c780562e9d830_%24teal_04.svg" loading="lazy" height="90" alt="" class="image-5"/>
                    <div class="descrip-impact inner-block">diverted</div>
                    <div class="w-dyn-list">
                        <div role="list" class="w-dyn-items">
                            <div role="listitem" class="w-dyn-item">
                                <div class="descrip-impact inner-block highlight-number">0</div>
                            </div>
                        </div>
                    </div>
                    <div class="descrip-impact inner-block">pounds of food waste.</div>
                </div>
                <div class="box light-teal">
                    <img src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/62448ea4ecc2edcc12061b49_%24teal_06.svg" loading="lazy" width="101" height="80" alt="" class="image-5"/>
                    <div class="descrip-impact inner-block">created</div>
                    <div class="w-dyn-list">
                        <div role="list" class="w-dyn-items">
                            <div role="listitem" class="w-dyn-item">
                                <div class="descrip-impact inner-block highlight-number">0</div>
                            </div>
                        </div>
                    </div>
                    <div class="descrip-impact inner-block">pounds of compost.</div>
                </div>

            </div>
        </div>
    </div>
</div>



<div class="section reviews wf-section">
    <div class="my-contain reviews _4">
        <h5 class="h5 light-teal center">Give Your Bucket Today!</h5>
        <h4 class="h4 center _36pt-padding">Your first week home collection service are free.</h4>
        <a href="" class="cta-btn label outline-btn teal center w-button">start composting With Us</a>
    </div>
</div>

<div class="footer_section layout_padding">
    <div class="container">

        <div class="location_main">
            <div class="call_text"><img src="images/call-icon.png"></div>
            <div class="call_text"><a href="#">Call +0 1234567890</a></div>
            <div class="call_text"><img src="images/mail-icon.png"></div>
            <div class="call_text"><a href="#">demo@example.com</a></div>
        </div>
        <div class="social_icon">
            <ul>
                <li><a href="#"><img src="images/fb-icon.png"></a></li>
                <li><a href="#"><img src="images/twitter-icon.png"></a></li>
                <li><a href="#"><img src="images/linkedin-icon.png"></a></li>
                <li><a href="#"><img src="images/instagram-icon.png"></a></li>
            </ul>
        </div>
    </div>
</div>



<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
<!-- javascript -->
<script src="js/owl.carousel.js"></script>
<script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>




<script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=62448acf9513136f203e24a4" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://uploads-ssl.webflow.com/62448acf9513136f203e24a4/js/webflow.1536ede82.js" type="text/javascript"></script>
<!--[if lte IE 9]><script src="//cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif]-->
<!-- Bugfix for pagination in tabs: https://discourse.webflow.com/t/pagination-within-tabs/75297/12 -->

<script type="text/javascript" src="js/mdb.min.js"></script>
<!-- Custom scripts -->
<script type="text/javascript"></script>
<script type="text/javascript">

    $(document).ready(function() {

        function activate(tab) {
            // switch all tabs off
            $(".w--current").removeClass(" w--current");

            // switch this tab on
            tab.addClass("w--current");
        }
        if (localStorage) {
            // let's not crash if some user has IE7
            var index = parseInt(localStorage['tab'] || '0');
            activate($('.w-tab-link').eq(index));
        }

        // When a link is clicked
        $(".w-tab-link").click(function() {
            if (localStorage)
                localStorage['tab'] = $(this).index();
            activate($(this));
        });

    });
</script>
<script>
    (function() {
        'use strict';

        document.addEventListener('DOMContentLoaded', function() {
            const searchParams = new URLSearchParams(window.location.search);

            function getCookie(key) {
                return document.cookie.split('; ').find((row)=>row.startsWith(key + '='))?.split('=')[1];
            }

            let date = new Date();
            let expires = date.setTime(date.getTime() + 365 * 24 * 60 * 60 * 1000);
            // One year

            // Handle offers
            let offer = searchParams.get('offer');

            if (!offer && typeof pageOffer !== 'undefined') {
                //let pageOffer = window.location.pathname.split('/').pop();
                offer = pageOffer;
            }

            if (offer) {
                document.cookie = 'offer=' + offer + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                offer = getCookie('offer');
            }

            if (offer) {
                document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                        let href = link.getAttribute('href').replace("/sign-up/", "/sign-up/home/" + offer + "/");
                        link.setAttribute('href', href);
                    }
                );
            }

            // Handle referrals
            let refCode = searchParams.get('cn_ref_code');
            if (refCode.indexOf('?') !== -1) {
                // Strip breaking appended search params
                refCode = refCode.substring(0, refCode.indexOf('?'));
            }

            if (refCode) {
                document.cookie = 'cn_ref_code=' + refCode + '; expires=' + expires + '; path=/; domain=compostnow.org';
            } else {
                refCode = getCookie('cn_ref_code');
            }

            const keys = ['utm_campaign', 'utm_content', 'utm_medium', 'utm_source', 'cn_ref_code', 'fbuy_ref_code'];
            document.querySelectorAll('a[href*="compostnow.org/sign-up/"]').forEach((link)=>{
                    let href = link.getAttribute('href');

                    keys.forEach((key,index)=>{
                            if (href.indexOf(key) !== -1) {
                                return;
                            }

                            let val = searchParams.get(key);
                            if (val) {
                                href += href.indexOf('?') === -1 ? '?' : '&';
                                if (val.indexOf('?') !== -1) {
                                    // Strip breaking appended search params
                                    val = val.substring(0, val.indexOf('?'));
                                }
                                href += `${key}=${val}`;
                            }
                        }
                    );

                    if (refCode && href.indexOf('cn_ref_code') === -1) {
                        href += (href.indexOf('?') === -1 ? '?' : '&');
                        href += `cn_ref_code=${refCode}`;
                    }

                    link.setAttribute('href', href);
                }
            );
        }, false);

    }());
</script>

</body>
</html>
<?php /**PATH C:\commision\CompostMates\resources\views/compost.blade.php ENDPATH**/ ?>